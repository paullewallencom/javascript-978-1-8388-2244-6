## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/practice-javascript-build-5-interactive-mini-applications-from-scratch-video/9781838822446)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Practice-JavaScript---Build-5-Interactive-Mini-Applications-from-Scratch
Code Repository for Practice JavaScript - Build 5 Interactive Mini Applications from Scratch, published by Packt
